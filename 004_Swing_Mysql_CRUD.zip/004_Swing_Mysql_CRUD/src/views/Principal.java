package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Principal {

	public JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAccesoOk = new JLabel("Acceso ok");
		lblAccesoOk.setBounds(0, 0, 434, 14);
		lblAccesoOk.setForeground(Color.RED);
		lblAccesoOk.setBackground(Color.ORANGE);
		frame.getContentPane().add(lblAccesoOk);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"id", "usuario", "contrase\u00F1a", "estado"},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		table.setBounds(72, 36, 280, 133);
		frame.getContentPane().add(table);
	}
}
