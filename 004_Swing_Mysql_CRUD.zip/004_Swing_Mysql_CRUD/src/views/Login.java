package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import config.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frmAccesoADatos;
	private JTextField textUsuario;
	private JTextField textPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoADatos.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoADatos = new JFrame();
		frmAccesoADatos.getContentPane().setBackground(Color.ORANGE);
		frmAccesoADatos.getContentPane().setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(Color.RED);
		lblNombre.setBounds(38, 45, 64, 14);
		frmAccesoADatos.getContentPane().add(lblNombre);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setForeground(Color.RED);
		lblContrasea.setBounds(38, 118, 64, 14);
		frmAccesoADatos.getContentPane().add(lblContrasea);
		
		textUsuario = new JTextField();
		textUsuario.setBounds(141, 42, 130, 20);
		frmAccesoADatos.getContentPane().add(textUsuario);
		textUsuario.setColumns(10);
		
		textPassword = new JTextField();
		textPassword.setBounds(141, 112, 130, 20);
		frmAccesoADatos.getContentPane().add(textPassword);
		textPassword.setColumns(10);
		
		JButton btnLogin = new JButton("New button");
		btnLogin.setBackground(Color.RED);
		btnLogin.setForeground(Color.BLACK);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				acceder();
			}
		});
		btnLogin.setBounds(141, 175, 130, 23);
		frmAccesoADatos.getContentPane().add(btnLogin);
		frmAccesoADatos.setTitle("Acceso a datos");
		frmAccesoADatos.setBounds(100, 100, 450, 300);
		frmAccesoADatos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	private void acceder() {
		Connection conn = new Conexion().conectar();
		
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE username=? AND password=?");
			ps.setString(1, textUsuario.getText());
			ps.setString(2, textPassword.getText());
			
			ResultSet rs = ps.executeQuery();
			
			//System.out.println(rs.next());
			
			if(rs.next()) {
				Principal p = new Principal();
				p.frame.setVisible(true);
			}else {
				JOptionPane.showMessageDialog(null, "error de login");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}//cierra acceder
}
